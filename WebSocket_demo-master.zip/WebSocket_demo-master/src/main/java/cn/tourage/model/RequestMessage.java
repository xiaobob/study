package cn.tourage.model;

/**
 * 接收来自浏览器的消息
 */
public class  RequestMessage {

    private String name;

    public String getName() {
        return name;
    }

}
